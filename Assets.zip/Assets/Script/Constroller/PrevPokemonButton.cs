using UnityEngine;

public class PrevPokemonButton : MonoBehaviour
{
    public PokemonInfoController infoController;

    public void OnButtonClick()
    {
        infoController.ShowPreviousPokemon();
    }
}
