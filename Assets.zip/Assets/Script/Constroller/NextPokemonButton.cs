using UnityEngine;

public class NextPokemonButton : MonoBehaviour
{
    public PokemonInfoController infoController;

    public void OnButtonClick()
    {
        infoController.ShowNextPokemon();
    }
}
