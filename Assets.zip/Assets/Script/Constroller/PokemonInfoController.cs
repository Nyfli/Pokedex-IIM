using UnityEngine;
using UnityEngine.UI;

public class PokemonInfoController : MonoBehaviour
{
    [SerializeField] private Image _ImgPokemon;
    [SerializeField] private Text _TxtName;
    [SerializeField] private Text _TxtNumber;
    [SerializeField] private Text _Txtsize;
    [SerializeField] private Text _TxtWeight;
    [SerializeField] private Text _TxtType;
    [SerializeField] private Text _TxtAbility;
    [SerializeField] private Text _TxtCaption;

    public PokemonDataBase database;
    private int currentIndex = 0;

    private void Start()
    {
        if (database == null)
        {
            Debug.LogError("Database reference is not set in PokemonInfoController!");
            return;
        }

        database.CreateData();
        ShowCurrentPokemon();
    }

    private void ShowCurrentPokemon()
    {
        if (database.datas.Count == 0)
        {
            Debug.LogError("No Pokemon data available in the database!");
            return;
        }

        PokemonData currentPokemon = database.datas[currentIndex];
        _ImgPokemon.sprite = currentPokemon.pokemonSprite;
        _TxtName.text = currentPokemon.name;
        _TxtNumber.text = currentPokemon.number.ToString();
        _Txtsize.text = currentPokemon.size;
        _TxtWeight.text = currentPokemon.weight;
        _TxtType.text = currentPokemon.type;
        _TxtAbility.text = currentPokemon.ability;
        _TxtCaption.text = currentPokemon.caption;
    }

    public void ShowNextPokemon()
    {
        if (currentIndex < database.datas.Count - 1)
        {
            currentIndex++;
            ShowCurrentPokemon();
        }
        else
        {
            Debug.Log("No next Pokemon available.");
        }
    }

    public void ShowPreviousPokemon()
    {
        if (currentIndex > 0)
        {
            currentIndex--;
            ShowCurrentPokemon();
        }
        else
        {
            Debug.Log("No previous Pokemon available.");
        }
    }
}
