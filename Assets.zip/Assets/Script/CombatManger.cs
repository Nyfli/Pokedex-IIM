using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatManager : MonoBehaviour
{
    public PokemonData playerPokemon;
    public PokemonData enemyPokemon;
    public BattleUIController battleUIController;

    private bool isPlayerTurn = true;
    private bool combatEnded = false;

    private void Start()
    {
        StartCombat();
    }

    public void StartCombat()
    {
        // Initialisation du combat
        Debug.Log($"{playerPokemon.name} VS {enemyPokemon.name}");
        battleUIController.UpdateUI();
        battleUIController.EnableAttackButtons(true);
        StartCoroutine(CombatRoutine());
    }

    private IEnumerator CombatRoutine()
    {
        while (playerPokemon.stats.hp > 0 && enemyPokemon.stats.hp > 0)
        {
            if (isPlayerTurn)
            {
                battleUIController.EnableAttackButtons(true);
                yield return new WaitUntil(() => !isPlayerTurn); 
            }
            else
            {
                EnemyAttack();
                battleUIController.UpdateUI();
                if (playerPokemon.stats.hp <= 0)
                {
                    Debug.Log("Player defeated!");
                    EndCombat("Enemy");
                    yield break;
                }

                isPlayerTurn = true;
                yield return new WaitForSeconds(1);
            }
        }
    }

    public void PlayerAttack(AttackData attack)
    {
        if (combatEnded) return;

        battleUIController.EnableAttackButtons(false);
        int damage = CalculateDamage(playerPokemon, enemyPokemon, attack);
        enemyPokemon.stats.hp -= damage;
        Debug.Log($"{playerPokemon.name} uses {attack.name} and attacks {enemyPokemon.name} for {damage} damage. Enemy HP: {enemyPokemon.stats.hp}");

        if (enemyPokemon.stats.hp <= 0)
        {
            Debug.Log("Enemy defeated!");
            EndCombat("Player");
            return;
        }

        isPlayerTurn = false;
        StartCoroutine(CombatRoutine());
    }

    private void EnemyAttack()
    {
        if (combatEnded) return;


        AttackData attack = enemyPokemon.attacks[0];
        int damage = CalculateDamage(enemyPokemon, playerPokemon, attack);
        playerPokemon.stats.hp -= damage;
        Debug.Log($"{enemyPokemon.name} uses {attack.name} and attacks {playerPokemon.name} for {damage} damage. Player HP: {playerPokemon.stats.hp}");

        if (playerPokemon.stats.hp <= 0)
        {
            Debug.Log("Player defeated!");
            EndCombat("Enemy");
        }
    }

    private int CalculateDamage(PokemonData attacker, PokemonData defender, AttackData attack)
    {

        int damage = attack.power + attacker.stats.atk - defender.stats.def;
        return Mathf.Max(damage, 1); 
    }

    private void EndCombat(string winner)
    {
        combatEnded = true;
        battleUIController.ShowEndMessage(winner);
    }
}
