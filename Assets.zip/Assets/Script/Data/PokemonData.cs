using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PokemonData
{
    [Serializable]
    public struct Stats
    {
        public int hp;
        public int atk;
        public int def;
        public int atkSpe;
        public int defSpe;
        public int speed;

        public Stats(int hp, int atk, int def, int atkSpe, int defSpe, int speed)
        {
            this.hp = hp;
            this.atk = atk;
            this.def = def;
            this.atkSpe = atkSpe;
            this.defSpe = defSpe;
            this.speed = speed;
        }
    }

    public string name;
    public int number;
    public string type;
    public string size;
    public string weight;
    public string ability;
    public string caption;
    public Sprite pokemonSprite;
    public Stats stats;
    public List<AttackData> attacks;

    public PokemonData()
    {
        attacks = new List<AttackData>();
    }

    public PokemonData(string name, int number, string type, string size, string weight, string ability, string caption, Sprite pokemonSprite, Stats stats, List<AttackData> attacks)
    {
        this.name = name;
        this.number = number;
        this.type = type;
        this.size = size;
        this.weight = weight;
        this.ability = ability;
        this.caption = caption;
        this.pokemonSprite = pokemonSprite;
        this.stats = stats;
        this.attacks = attacks;
    }
}
