using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName = "Pokemon", menuName = "Database/Pokemon", order = 0)]
public class PokemonDataBase : ScriptableObject
{
    public List<PokemonData> datas = new List<PokemonData>();

    public void CreateData()
    {
        // Ajoutez les donn�es pour les 10 Pok�mon
        AddPokemonData("Bulbizarre", 1, "Plante", "0.7m", "6.9kg", "Engrais", "Bulbizarre peut �tre vu en train de faire la sieste au soleil. Il y a une graine sur son dos. En absorbant les rayons du soleil, la graine grandit progressivement.", null);
        AddPokemonData("Salam�che", 4, "Feu", "0.6m", "8.5kg", "Brasier", "Salam�che a une flamme constamment allum�e au bout de sa queue. Elle br�le de diff�rentes intensit�s selon les �motions de ce Pok�mon.", null);
        // Ajoutez les donn�es pour les autres Pok�mon de mani�re similaire
    }

    private void AddPokemonData(string name, int number, string type, string size, string weight, string ability, string caption, Sprite pokemonSprite = null)
    {
        PokemonData.Stats stats = new PokemonData.Stats();
        datas.Add(new PokemonData(name, number, type, size, weight, ability, caption, pokemonSprite, stats));
    }
}
