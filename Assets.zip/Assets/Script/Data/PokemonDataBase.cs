using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PokemonDatabase", menuName = "Pokemon/Database")]
public class PokemonDatabase : ScriptableObject
{
    public List<PokemonData> datas;

    public void InitializeDatabase()
    {
        datas = new List<PokemonData>();


        List<AttackData> pikachuAttacks = new List<AttackData>
        {
            new AttackData("Thunder Shock", 40, "Electric"),
            new AttackData("Quick Attack", 30, "Normal")
        };


        List<AttackData> charmanderAttacks = new List<AttackData>
        {
            new AttackData("Ember", 40, "Fire"),
            new AttackData("Scratch", 40, "Normal")
        };


        datas.Add(new PokemonData("Pikachu", 25, "Electric", "0.4m", "6kg", "Static", "A friendly electric mouse", null, new PokemonData.Stats(35, 55, 40, 50, 50, 90), pikachuAttacks));
        datas.Add(new PokemonData("Charmander", 4, "Fire", "0.6m", "8.5kg", "Blaze", "A fiery lizard", null, new PokemonData.Stats(39, 52, 43, 60, 50, 65), charmanderAttacks));
    }
}
