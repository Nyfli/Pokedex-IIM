using System;
using UnityEngine;

[Serializable]
public class AttackData
{
    public string name;
    public int power;
    public string type;

    public AttackData(string name, int power, string type)
    {
        this.name = name;
        this.power = power;
        this.type = type;


    }


}
