using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleUIController : MonoBehaviour
{
    public TMP_Text playerPokemonName;
    public TMP_Text playerPokemonHP;
    public TMP_Text enemyPokemonName;
    public TMP_Text enemyPokemonHP;

    public CombatManager combatManager;

    public TMP_Text attack1ButtonText;
    public TMP_Text attack2ButtonText;
    public Button attack1Button;
    public Button attack2Button;

    public TMP_Text endMessage; 

    private void Start()
    {
        UpdateUI();
        SetupAttackButtons();
        endMessage.gameObject.SetActive(false);
    }

    public void SetupAttackButtons()
    {
        attack1ButtonText.text = combatManager.playerPokemon.attacks[0].name;
        attack2ButtonText.text = combatManager.playerPokemon.attacks[1].name;

        attack1Button.onClick.AddListener(() => combatManager.PlayerAttack(combatManager.playerPokemon.attacks[0]));
        attack2Button.onClick.AddListener(() => combatManager.PlayerAttack(combatManager.playerPokemon.attacks[1]));
    }

    public void EnableAttackButtons(bool enable)
    {
        attack1Button.interactable = enable;
        attack2Button.interactable = enable;
    }

    public void UpdateUI()
    {
        playerPokemonName.text = combatManager.playerPokemon.name;
        playerPokemonHP.text = "HP: " + combatManager.playerPokemon.stats.hp;
        enemyPokemonName.text = combatManager.enemyPokemon.name;
        enemyPokemonHP.text = "HP: " + combatManager.enemyPokemon.stats.hp;
    }

    public void ShowEndMessage(string winner)
    {
        endMessage.gameObject.SetActive(true);
        endMessage.text = winner == "Player" ? "You Win!" : "You Lose!";
    }
}
