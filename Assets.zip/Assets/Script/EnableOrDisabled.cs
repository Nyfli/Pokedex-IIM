using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnableOrDisable : MonoBehaviour
{
    public GameObject pic;

    public void Trigger()
    {

    }
}
